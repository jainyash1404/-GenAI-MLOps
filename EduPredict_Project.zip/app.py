import streamlit as st
import pandas as pd
import joblib
import os
import json

from datetime import datetime
from genai_recommendation import generate_recommendations

# Page configuration
st.set_page_config(
    page_title="EduPredict AI",
    page_icon="🎓",
    layout="wide"
)

st.markdown("""
<style>

@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

.stApp {
    background: #080D19;
    color: #F8FAFC;
}

[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #111B30, #0B1220);
    border-right: 1px solid #26334B;
}

[data-testid="stSidebar"] h1,
[data-testid="stSidebar"] h2 {
    color: #FFFFFF;
}

h1 {
    color: #FFFFFF !important;
    font-weight: 800 !important;
}

h2, h3 {
    color: #E2E8F0 !important;
    font-weight: 700 !important;
}

p, label {
    color: #AAB8CE !important;
}

[data-testid="stMetric"] {
    background: linear-gradient(135deg, #17243B, #111B30);
    border: 1px solid #293B5B;
    padding: 22px;
    border-radius: 16px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.2);
}

[data-testid="stMetricValue"] {
    color: #60A5FA !important;
    font-size: 30px !important;
    font-weight: 800 !important;
}

[data-testid="stMetricLabel"] {
    color: #AAB8CE !important;
}

.stButton > button {
    background: linear-gradient(90deg, #2563EB, #7C3AED);
    color: white !important;
    border: none;
    border-radius: 10px;
    padding: 12px 24px;
    font-weight: 700;
    transition: 0.3s;
    width: 100%;
}

.stButton > button:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(99,102,241,0.35);
}

[data-testid="stSlider"] [role="slider"] {
    background: #818CF8;
}

[data-testid="stExpander"] {
    background: #111B30;
    border: 1px solid #293B5B;
    border-radius: 12px;
}

[data-testid="stDataFrame"] {
    border: 1px solid #293B5B;
    border-radius: 12px;
}

hr {
    border-color: #293B5B;
}

.block-container {
    padding-top: 2rem;
    padding-bottom: 3rem;
    max-width: 1400px;
}

</style>
""", unsafe_allow_html=True)

# Load model
@st.cache_resource
def load_model():
    return joblib.load("models/student_model.pkl")

model = load_model()

# Create logs folder
os.makedirs("logs", exist_ok=True)

LOG_FILE = "logs/predictions.csv"

# Custom styling
st.markdown("""
<style>
.main {
    background-color: #f5f7fb;
}
.stButton>button {
    background-color: #2563eb;
    color: white;
    border-radius: 10px;
    width: 100%;
    height: 45px;
}
</style>
""", unsafe_allow_html=True)

# Header
st.title("🎓 EduPredict AI")

st.subheader(
    "Smart Student Performance Prediction & Recommendation System"
)

st.write(
    "Predict academic performance using Machine Learning "
    "and receive personalized recommendations using Generative AI."
)

st.divider()

# Sidebar
st.sidebar.header("Student Information")

attendance = st.sidebar.slider(
    "Attendance (%)", 35, 100, 80
)

study_hours = st.sidebar.slider(
    "Daily Study Hours", 0.0, 8.0, 3.0
)

previous_score = st.sidebar.slider(
    "Previous Exam Score", 30, 100, 65
)

assignment_completion = st.sidebar.slider(
    "Assignment Completion (%)", 20, 100, 75
)

sleep_hours = st.sidebar.slider(
    "Daily Sleep Hours", 3.0, 10.0, 7.0
)

# Student input
student_data = {
    "attendance": attendance,
    "study_hours": study_hours,
    "previous_score": previous_score,
    "assignment_completion": assignment_completion,
    "sleep_hours": sleep_hours
}

st.header("Student Performance Analysis")

col1, col2, col3 = st.columns(3)

col1.metric("Attendance", f"{attendance}%")
col2.metric("Study Hours", f"{study_hours} hrs")
col3.metric("Previous Score", f"{previous_score}/100")

# Prediction button
if st.button("Predict Student Performance"):

    input_df = pd.DataFrame([student_data])

    # ML prediction
    prediction = float(model.predict(input_df)[0])

    prediction = max(0, min(100, prediction))

    # Risk classification
    if prediction >= 70:
        risk = "Low"
    elif prediction >= 50:
        risk = "Moderate"
    else:
        risk = "High"

    st.divider()

    st.header("ML Prediction Results")

    c1, c2 = st.columns(2)

    c1.metric(
        "Predicted Final Score",
        f"{prediction:.2f}/100"
    )

    c2.metric(
        "Academic Risk",
        risk
    )

    st.progress(int(prediction))

    # GenAI recommendations
    st.divider()

    st.header("🤖 AI Study Recommendations")

    with st.spinner("Gemini AI is generating recommendations..."):

        recommendations = generate_recommendations(
            student_data,
            prediction
        )

    st.markdown(recommendations)

    # Monitoring
    st.divider()

    st.header("MLOps Monitoring")

    # Input distribution monitoring
    with open("data/training_stats.json", "r") as f:
        stats = json.load(f)

    unusual_features = []

    for feature, value in student_data.items():

        mean = stats[feature]["mean"]
        std = max(stats[feature]["std"], 0.0001)

        if abs(value - mean) > 2 * std:
            unusual_features.append(feature)

    if unusual_features:
        st.warning(
            "Unusual input detected: "
            + ", ".join(unusual_features)
        )
    else:
        st.success("All input values are within normal training ranges.")

    # Save prediction log
    log_data = {
        **student_data,
        "predicted_score": prediction,
        "risk": risk,
        "timestamp": datetime.now().isoformat()
    }

    log_df = pd.DataFrame([log_data])

    log_df.to_csv(
        LOG_FILE,
        mode="a",
        header=not os.path.exists(LOG_FILE),
        index=False
    )

    st.success("Prediction saved successfully!")

# Display prediction history
st.divider()

st.header("Prediction History")

if os.path.exists(LOG_FILE):

    history = pd.read_csv(LOG_FILE)

    st.metric(
        "Total Predictions",
        len(history)
    )

    st.dataframe(
        history.tail(10),
        use_container_width=True
    )

else:

    st.info("No predictions available yet.")